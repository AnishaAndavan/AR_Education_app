using UnityEngine;
using UnityEngine.SceneManagement;

public class ChapterSceneLoader : MonoBehaviour
{
    public void LoadChapterTutorial(string tutorialSceneName)
    {
        ChapterManager.Instance.SetChapter(tutorialSceneName); // Store the chapter name
        SceneManager.LoadScene(tutorialSceneName);  // Load tutorial scene first
    }
}
