using UnityEngine;
using UnityEngine.UI;

public class ARObjectController : MonoBehaviour
{
    private bool canRotate = false;
    private bool canScale = false;
    private bool canMove = false;

    public float rotateSpeed = 0.2f;
    public float scaleSpeed = 0.01f;
    public float moveSpeed = 0.001f; // Move speed for smooth movement

    public Text infoPanelText; // Reference to Legacy Text UI

    private void Start()
    {
        UpdateInfoPanel("Select an action");
    }

    private void Update()
    {
        if (Input.touchCount == 1 && canMove)
        {
            MoveObject();
        }
        else if (Input.touchCount == 2)
        {
            if (canRotate)
            {
                RotateObject();
            }
            else if (canScale)
            {
                ScaleObject();
            }
        }
    }

    private void MoveObject()
    {
        Touch touch = Input.GetTouch(0);
        if (touch.phase == TouchPhase.Moved)
        {
            Vector2 touchDelta = touch.deltaPosition * moveSpeed;
            Vector3 move = new Vector3(touchDelta.x, touchDelta.y, 0);
            transform.Translate(move, Space.World);
        }
    }

    private void RotateObject()
    {
        Touch touch1 = Input.GetTouch(0);
        Touch touch2 = Input.GetTouch(1);

        Vector2 prevPos1 = touch1.position - touch1.deltaPosition;
        Vector2 prevPos2 = touch2.position - touch2.deltaPosition;

        float prevAngle = Mathf.Atan2(prevPos2.y - prevPos1.y, prevPos2.x - prevPos1.x) * Mathf.Rad2Deg;
        float currentAngle = Mathf.Atan2(touch2.position.y - touch1.position.y, touch2.position.x - touch1.position.x) * Mathf.Rad2Deg;

        float angleDifference = currentAngle - prevAngle;
        transform.Rotate(0, angleDifference * rotateSpeed, 0, Space.World);
    }

    private void ScaleObject()
    {
        Touch touch1 = Input.GetTouch(0);
        Touch touch2 = Input.GetTouch(1);

        float prevDistance = Vector2.Distance(touch1.position - touch1.deltaPosition, touch2.position - touch2.deltaPosition);
        float currentDistance = Vector2.Distance(touch1.position, touch2.position);

        float pinchAmount = (currentDistance - prevDistance) * scaleSpeed;
        transform.localScale += Vector3.one * pinchAmount;
    }

    public void EnableRotate()
    {
        canRotate = true;
        canScale = false;
        canMove = false;
        UpdateInfoPanel("🔄 Rotate: Use two fingers to rotate the object.");
    }

    public void EnableScale()
    {
        canRotate = false;
        canScale = true;
        canMove = false;
        UpdateInfoPanel("🔍 Scale: Use two fingers to zoom in/out.");
    }

    public void EnableMove()
    {
        canRotate = false;
        canScale = false;
        canMove = true;
        UpdateInfoPanel("📍 Move: Drag with one finger to move.");
    }

    private void UpdateInfoPanel(string message)
    {
        if (infoPanelText != null)
        {
            infoPanelText.text = message;
        }
    }
}
