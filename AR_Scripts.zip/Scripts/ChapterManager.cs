﻿using UnityEngine;

public class ChapterManager : MonoBehaviour
{
    public static ChapterManager Instance { get; private set; }
    private string selectedChapterID;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);  // Keep across scenes
        }
        else
        {
            Destroy(gameObject);  // Prevent duplicate instances
        }
    }

    public void SetChapter(string chapterID)
    {
        if (!string.IsNullOrEmpty(chapterID))
        {
            selectedChapterID = chapterID;
        }
        else
        {
            Debug.LogError("❌ Invalid chapter ID!");
        }
    }

    public string GetChapter()
    {
        if (string.IsNullOrEmpty(selectedChapterID))
        {
            Debug.LogWarning("⚠️ Chapter ID not set. Defaulting to 'MarkerlessTut'.");
            return "MarkerlessTut"; // Default fallback
        }
        return selectedChapterID;
    }
}
