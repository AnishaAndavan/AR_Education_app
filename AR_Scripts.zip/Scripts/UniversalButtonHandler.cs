using UnityEngine;
using UnityEngine.UI;

public class UniversalButtonHandler : MonoBehaviour
{
    public enum ButtonType { CloseProfile, OpenProfile }

    public ButtonType buttonType;

    private ProfileManager profileManager;

    void Start()
    {
        profileManager = FindObjectOfType<ProfileManager>();

        if (GetComponent<Button>() != null)
        {
            GetComponent<Button>().onClick.AddListener(HandleButtonClick);
        }
    }

    void HandleButtonClick()
    {
        switch (buttonType)
        {
            case ButtonType.CloseProfile:
                if (profileManager != null)
                    profileManager.CloseProfilePanel();
                break;

            case ButtonType.OpenProfile:
                if (profileManager != null)
                    profileManager.OpenProfile();
                break;
        }
    }
}
