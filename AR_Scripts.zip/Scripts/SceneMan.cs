using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneMan : MonoBehaviour
{
    // Generic function to load any scene dynamically
    public void LoadScene(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
    }

    // Exits the application
    public void ExitApp()
    {
        Application.Quit();
    }
}
