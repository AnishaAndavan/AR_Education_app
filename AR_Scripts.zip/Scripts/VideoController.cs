using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Video;
using UnityEngine.EventSystems; // Required for pointer events

public class VideoController : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    public VideoPlayer videoPlayer;
    public Button playButton, stopButton;
    public Slider progressSlider;

    private bool isPaused = false;
    private bool isDragging = false;

    void Start()
    {
        playButton.onClick.AddListener(PlayVideo);
        stopButton.onClick.AddListener(PauseVideo);
        progressSlider.onValueChanged.AddListener(OnSliderValueChanged);
    }

    void Update()
    {
        // Update slider only if user is NOT dragging
        if (videoPlayer.isPlaying && !isDragging)
        {
            progressSlider.value = (float)(videoPlayer.time / videoPlayer.length);
        }
    }

    void PlayVideo()
    {
        if (isPaused)
        {
            videoPlayer.Play();
            isPaused = false;
        }
        else if (!videoPlayer.isPlaying)
        {
            videoPlayer.Play();
        }
    }

    void PauseVideo()
    {
        if (videoPlayer.isPlaying)
        {
            videoPlayer.Pause();
            isPaused = true;
        }
    }

    public void OnSliderValueChanged(float value)
    {
        if (isDragging) // Only seek when user is actively dragging
        {
            videoPlayer.time = value * videoPlayer.length;
        }
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        isDragging = true;
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        isDragging = false;
        videoPlayer.time = progressSlider.value * videoPlayer.length;
    }
}
