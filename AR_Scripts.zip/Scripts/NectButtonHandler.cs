using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement; // If you need to change scenes

public class NectButtonHandler : MonoBehaviour
{
    public Text infoText; // Assign the text UI
    public Button changeSceneButton; // Assign the hidden button

    void Start()
    {
        changeSceneButton.gameObject.SetActive(false); // Hide the button initially
    }

    public void OnNextButtonClick()
    {
        infoText.gameObject.SetActive(false); // Hide text
        changeSceneButton.gameObject.SetActive(true); // Show scene change button
    }
}
