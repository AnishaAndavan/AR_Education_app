using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using Firebase;
using Firebase.Database;
using Firebase.Extensions;

public class DatabaseManager : MonoBehaviour
{
    public static string userId;     
    public static string username;
    public static string userEmail;  // ✅ Added this line to store the logged-in email

    public InputField EmailInput;    // ✅ New input field for email
    public InputField UsernameInput;
    public InputField PasswordInput;
    public Button RegisterButton;
    public Button LoginButton;

    public GameObject NotificationPanel;
    public Text NotificationText;

    private DatabaseReference dbReference;
    private bool isProcessing = false;

    void Start()
    {
        FirebaseApp.CheckAndFixDependenciesAsync().ContinueWithOnMainThread(task =>
        {
            if (task.Result == DependencyStatus.Available)
            {
                dbReference = FirebaseDatabase.DefaultInstance.RootReference;
                Debug.Log("✅ Firebase Initialized.");

                if (RegisterButton != null)
                {
                    RegisterButton.onClick.RemoveAllListeners();
                    RegisterButton.onClick.AddListener(RegisterUser);
                }

                if (LoginButton != null)
                {
                    LoginButton.onClick.RemoveAllListeners();
                    LoginButton.onClick.AddListener(LoginUser);
                }

                if (NotificationPanel != null)
                    NotificationPanel.SetActive(false);

                CheckUserSession();
            }
            else
            {
                Debug.LogError("❌ Firebase Initialization Failed: " + task.Result);
            }
        });
    }

    IEnumerator ShowNotification(string message, Color color, bool changeScene = false, string sceneName = "")
    {
        if (NotificationText == null || NotificationPanel == null)
        {
            Debug.LogError("❌ Notification UI references are missing in the inspector.");
            yield break;
        }

        NotificationText.text = message;
        NotificationText.color = color;
        NotificationPanel.SetActive(true);

        yield return new WaitForSeconds(2);

        NotificationPanel.SetActive(false);

        if (changeScene && !string.IsNullOrEmpty(sceneName))
        {
            SceneManager.LoadScene(sceneName);
        }

        if (RegisterButton != null) RegisterButton.interactable = true;
        if (LoginButton != null) LoginButton.interactable = true;
        isProcessing = false;
    }

    public void RegisterUser()
    {
        if (isProcessing) return;
        isProcessing = true;

        string email = EmailInput.text.Trim();
        string username = UsernameInput.text.Trim();
        string password = PasswordInput.text.Trim();

        if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
        {
            StartCoroutine(ShowNotification("⚠️ Enter Email, Username & Password!", Color.yellow));
            return;
        }

        RegisterButton.interactable = false;

        dbReference.Child("users").OrderByChild("email").EqualTo(email).GetValueAsync().ContinueWithOnMainThread(task =>
        {
            if (task.IsCompleted)
            {
                DataSnapshot snapshot = task.Result;

                if (snapshot.Exists)
                {
                    StartCoroutine(ShowNotification("⚠️ Email already registered!", Color.red));
                }
                else
                {
                    string userKey = dbReference.Child("users").Push().Key;
                    User newUser = new User(email, username, password);
                    string json = JsonUtility.ToJson(newUser);

                    dbReference.Child("users").Child(userKey).SetRawJsonValueAsync(json).ContinueWithOnMainThread(storeTask =>
                    {
                        if (storeTask.IsCompleted)
                        {
                            StartCoroutine(ShowNotification("✅ Registration Successful!", Color.green, true, "Login"));
                        }
                        else
                        {
                            StartCoroutine(ShowNotification("❌ Registration Failed!", Color.red));
                        }
                    });
                }
            }
            else
            {
                StartCoroutine(ShowNotification("❌ Registration Error!", Color.red));
            }
        });
    }

    public void LoginUser()
    {
        if (isProcessing) return;
        isProcessing = true;

        string emailInput = EmailInput.text.Trim();
        string password = PasswordInput.text.Trim();

        if (string.IsNullOrEmpty(emailInput) || string.IsNullOrEmpty(password))
        {
            StartCoroutine(ShowNotification("⚠️ Enter Email & Password!", Color.yellow));
            return;
        }

        LoginButton.interactable = false;

        dbReference.Child("users").OrderByChild("email").EqualTo(emailInput).GetValueAsync().ContinueWithOnMainThread(task =>
        {
            if (task.IsCompleted)
            {
                DataSnapshot snapshot = task.Result;

                if (snapshot.Exists)
                {
                    foreach (DataSnapshot user in snapshot.Children)
                    {
                        string storedPassword = user.Child("password").Value.ToString();

                        if (storedPassword == password)
                        {
                            userId = user.Key;
                            username = user.Child("username").Value.ToString(); // ✅ Get username from database
                            userEmail = emailInput; // ✅ Store logged-in email
                            PlayerPrefs.SetString("userId", userId);
                            PlayerPrefs.SetString("username", username);
                            PlayerPrefs.SetString("userEmail", userEmail);
                            PlayerPrefs.Save();
                            StartCoroutine(ShowNotification("✅ Login Successful!", Color.green, true, "Module"));
                        }
                        else
                        {
                            StartCoroutine(ShowNotification("❌ Incorrect Password!", Color.red));
                        }
                        return;
                    }
                }
                else
                {
                    StartCoroutine(ShowNotification("❌ Email Not Found!", Color.red));
                }
            }
            else
            {
                StartCoroutine(ShowNotification("❌ Login Error!", Color.red));
            }
        });
    }

    public void CheckUserSession()
{
    if (string.IsNullOrEmpty(userId) && PlayerPrefs.HasKey("userId"))
    {
        userId = PlayerPrefs.GetString("userId");
        username = PlayerPrefs.GetString("username");
        userEmail = PlayerPrefs.GetString("userEmail"); // ✅ Restore email from PlayerPrefs
    }

    string currentScene = SceneManager.GetActiveScene().name;
    
    // ✅ Prevent redirect if on Login or Register scene
    if (string.IsNullOrEmpty(userId) && currentScene != "Login" && currentScene != "Register")
    {
        SceneManager.LoadScene("Login");
    }
}

}

[System.Serializable]
public class User
{
    public string email;
    public string username;
    public string password;

    public User(string email, string username, string password)
    {
        this.email = email;
        this.username = username;
        this.password = password;
    }
}

[System.Serializable]
public class ChapterProgress
{
    public bool tutorialCompleted;
    public int quizScore;
    public string username;
    public string email; 

    public ChapterProgress(bool tutorialCompleted, int quizScore, string username, string email)
    {
        this.tutorialCompleted = tutorialCompleted;
        this.quizScore = quizScore;
        this.username = username;
        this.email = email;
    }
}

