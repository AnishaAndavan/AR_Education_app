using UnityEngine;
using UnityEngine.UI;

public class OpenProfileButton : MonoBehaviour
{
    void Start()
    {
        GetComponent<Button>().onClick.AddListener(OpenProfilePanel);
    }

    void OpenProfilePanel()
    {
        var profileManager = FindObjectOfType<ProfileManager>();
        if (profileManager != null)
        {
            profileManager.OpenProfile();
        }
    }
}
