using UnityEngine;
using UnityEngine.UI;
using Firebase.Database;
using Firebase.Extensions;

public class ProfileManager : MonoBehaviour
{
    public GameObject profilePanel, editUsernamePanel, updatePasswordPanel;

    public Text usernameText, chapterProgressText, quizStatusText;
    public InputField newUsernameInput;
    public InputField currentPasswordInput, newPasswordInput, confirmPasswordInput;

    public Button closeButton, editUsernameButton, saveUsernameButton;
    public Button updatePasswordButton, savePasswordButton;

    private DatabaseReference database;
    private string userId;

    void Start()
    {
        database = FirebaseDatabase.DefaultInstance.RootReference;

        closeButton.onClick.AddListener(() => profilePanel.SetActive(false));
        editUsernameButton.onClick.AddListener(() => {
            Debug.Log("🟢 Edit Username Button Clicked");
            ShowEditUsernamePanel(true);
        });
        saveUsernameButton.onClick.AddListener(UpdateUsername);
        updatePasswordButton.onClick.AddListener(() => ShowPasswordPanel(true));
        savePasswordButton.onClick.AddListener(UpdatePassword);

        profilePanel.SetActive(false);
        ShowEditUsernamePanel(false);
        ShowPasswordPanel(false);
    }

    public void OpenProfile()
    {
        // ✅ Check if user is logged in
        if (string.IsNullOrEmpty(DatabaseManager.userId))
        {
            Debug.LogError("⚠️ No user is currently logged in.");
            return;
        }

        userId = DatabaseManager.userId;

        profilePanel.SetActive(true);
        ShowEditUsernamePanel(false);
        ShowPasswordPanel(false);

        LoadUserProfileData();
        LoadProgress();
    }

    void ShowEditUsernamePanel(bool show) {
        Debug.Log($"🔄 ShowEditUsernamePanel called with: {show}");
        editUsernamePanel.SetActive(show);
    }

    void ShowPasswordPanel(bool show) => updatePasswordPanel.SetActive(show);

    public void LoadUserProfileData()
    {
        DatabaseReference userRef = FirebaseDatabase.DefaultInstance.GetReference($"users/{userId}");

        userRef.GetValueAsync().ContinueWithOnMainThread(task =>
        {
            if (task.IsFaulted || task.IsCanceled)
            {
                Debug.LogError("❌ Failed to load user data.");
                return;
            }

            DataSnapshot snapshot = task.Result;
            if (snapshot.Exists)
            {
                string username = snapshot.Child("username").Value?.ToString() ?? "N/A";

                // Update UI on main thread
                UnityMainThreadDispatcher.Instance().Enqueue(() =>
                {
                    usernameText.text = username;
                });
            }
            else
            {
                Debug.LogWarning("⚠️ No user data found.");
            }
        });
    }

    void LoadProgress()
    {
        database.Child("users").Child(userId).Child("progress").GetValueAsync().ContinueWithOnMainThread(task =>
        {
            if (!task.IsCompleted || task.Result == null)
            {
                Debug.LogError("❌ Progress data missing or failed to load.");
                return;
            }

            DataSnapshot progressSnapshot = task.Result;
            int completedChapters = 0;
            string allProgressDetails = "";

            foreach (DataSnapshot chapter in progressSnapshot.Children)
            {
                string chapterName = chapter.Key;

                bool tutorialCompleted = false;
                bool.TryParse(chapter.Child("tutorialCompleted").Value?.ToString(), out tutorialCompleted);

                if (tutorialCompleted) completedChapters++;

                string score = chapter.Child("quizScore").Exists ? chapter.Child("quizScore").Value.ToString() : "Not Attempted";

                allProgressDetails += $"📘 {chapterName}\n" +
                                      $"- Tutorial Completed: {(tutorialCompleted ? "✅ Yes" : "❌ No")}\n" +
                                      $"- Quiz Score: {score}\n\n";
            }

            chapterProgressText.text = $"📊 Completed Chapters: {completedChapters}";
            quizStatusText.text = allProgressDetails;
            Debug.Log("✅ Progress data loaded and displayed.");
        });
    }

    void UpdateUsername()
{
    string newUsername = newUsernameInput.text.Trim();

    // 1. Validate input
    if (string.IsNullOrEmpty(newUsername))
    {
        Debug.LogWarning("⚠️ Username cannot be empty.");
        return;
    }

    // 2. Update in main user node
    DatabaseReference userRef = database.Child("users").Child(userId);
    userRef.Child("username").SetValueAsync(newUsername).ContinueWithOnMainThread(task =>
    {
        if (task.IsFaulted || task.IsCanceled)
        {
            Debug.LogError("❌ Failed to update username in user node.");
            return;
        }

        // 3. Update in all progress chapters
        userRef.Child("progress").GetValueAsync().ContinueWithOnMainThread(progressTask =>
        {
            if (progressTask.IsCompleted && progressTask.Result.Exists)
            {
                foreach (DataSnapshot chapter in progressTask.Result.Children)
                {
                    string chapterKey = chapter.Key;
                    userRef.Child("progress").Child(chapterKey).Child("username").SetValueAsync(newUsername);
                }
            }

            // 4. Update UI & PlayerPrefs
            usernameText.text = newUsername;
            PlayerPrefs.SetString("username", newUsername);

            // 5. Close the panel
            ShowEditUsernamePanel(false);

            Debug.Log("✅ Username successfully updated.");
        });
    });
}


    public void UpdatePassword()
    {
        string currentPass = currentPasswordInput.text.Trim();
        string newPass = newPasswordInput.text.Trim();
        string confirmPass = confirmPasswordInput.text.Trim();

        if (string.IsNullOrEmpty(currentPass) || string.IsNullOrEmpty(newPass) || string.IsNullOrEmpty(confirmPass))
        {
            Debug.LogError("⚠️ Please fill in all password fields.");
            return;
        }

        if (newPass != confirmPass)
        {
            Debug.LogError("❌ New password and confirm password do not match.");
            return;
        }

        string userPath = $"users/{userId}/password";

        FirebaseDatabase.DefaultInstance.GetReference(userPath).GetValueAsync().ContinueWithOnMainThread(task =>
        {
            if (task.IsFaulted || task.IsCanceled)
            {
                Debug.LogError("❌ Error retrieving current password from database.");
                return;
            }

            DataSnapshot snapshot = task.Result;
            string storedPassword = snapshot.Value?.ToString();

            if (storedPassword == null)
            {
                Debug.LogError("❌ Stored password is null.");
                return;
            }

            if (currentPass != storedPassword)
            {
                Debug.LogError("❌ Current password is incorrect.");
                return;
            }

            // Password matched, update it
            FirebaseDatabase.DefaultInstance.GetReference(userPath).SetValueAsync(newPass).ContinueWithOnMainThread(updateTask =>
            {
                if (updateTask.IsFaulted || updateTask.IsCanceled)
                {
                    Debug.LogError("❌ Failed to update password.");
                }
                else
                {
                    Debug.Log("✅ Password updated successfully.");
                    currentPasswordInput.text = "";
                    newPasswordInput.text = "";
                    confirmPasswordInput.text = "";
                    ShowPasswordPanel(false);
                }
            });
        });
    }
    public void CloseProfilePanel()
{
    profilePanel.SetActive(false);
    ShowEditUsernamePanel(false);
    ShowPasswordPanel(false);
}
}
