using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class NotificationManager : MonoBehaviour
{
    public RectTransform notificationPanel; // Assign the panel
    public Text notificationText; // Assign the text
    public float slideSpeed = 0.02f; // Adjust speed

    private Vector2 hiddenPosition;
    private Vector2 visiblePosition;

    void Start()
    {
        // Store initial positions
        hiddenPosition = notificationPanel.anchoredPosition;
        visiblePosition = new Vector2(hiddenPosition.x, hiddenPosition.y - 150); // Adjust height
    }

    public void ShowNotification(string message)
    {
        notificationText.text = message; // Set message
        StopAllCoroutines();
        StartCoroutine(SlideInAndOut());
    }

    IEnumerator SlideInAndOut()
    {
        // Slide In
        float time = 0;
        while (time < slideSpeed)
        {
            notificationPanel.anchoredPosition = Vector2.Lerp(hiddenPosition, visiblePosition, time / slideSpeed);
            time += Time.deltaTime;
            yield return null;
        }
        notificationPanel.anchoredPosition = visiblePosition;

        yield return new WaitForSeconds(2); // Stay for 2 seconds

        // Slide Out
        time = 0;
        while (time < slideSpeed)
        {
            notificationPanel.anchoredPosition = Vector2.Lerp(visiblePosition, hiddenPosition, time / slideSpeed);
            time += Time.deltaTime;
            yield return null;
        }
        notificationPanel.anchoredPosition = hiddenPosition;
    }
}
