using UnityEngine;
using UnityEngine.UI;

public class InfoButton : MonoBehaviour
{
    public GameObject infoPanel; // Assign UI Panel
    public Text infoText; // Assign Text component
    private string currentInfo = "No object placed yet."; // Default text

    void Start()
    {
        infoPanel.SetActive(false); // Hide initially
    }

    public void ShowInfo()
    {
        infoPanel.SetActive(true); // Show panel
        infoText.text = currentInfo; // Show dynamic text
    }

    public void SetInfo(string newInfo)
    {
        currentInfo = newInfo; // Update info text dynamically
    }
}
