using UnityEngine;
using UnityEngine.UI;

public class InfoPanelController : MonoBehaviour
{
    public Text infoText;

    public void UpdateInfo(string message)
    {
        infoText.text = message;
    }
}
