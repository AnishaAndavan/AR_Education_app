using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class ObjectSwapper : MonoBehaviour
{
    public GameObject[] objects;
    private int currentIndex = 0;
    private GameObject currentObject;

    public Button rotateButton;
    public Button scaleButton;
    public Button moveButton;
    public Button nextButton;

    public Text infoText;
    public ScrollRect infoScrollView;

    private enum InteractionMode { None, Rotate, Scale, Move }
    private InteractionMode currentMode = InteractionMode.None;

    private Vector2 lastTouchPosition;
    private float initialDistance;
    private Vector3 initialScale;

    private Dictionary<string, string> objectInfo = new Dictionary<string, string>()
    {
        { "Markerless", "This object supports markerless tracking, allowing AR placement without physical markers." },
        { "Rotate", "Use touch gestures to rotate the object in all directions." },
        { "Scale", "Pinch with two fingers to scale the object uniformly." },
        { "Move", "Drag with one finger to move the object in any direction." }
    };

    void Start()
    {
        if (objects.Length > 0)
        {
            currentObject = objects[currentIndex];
            SetObjectActive();
        }

        rotateButton.onClick.AddListener(() => SetInteractionMode(InteractionMode.Rotate));
        scaleButton.onClick.AddListener(() => SetInteractionMode(InteractionMode.Scale));
        moveButton.onClick.AddListener(() => SetInteractionMode(InteractionMode.Move));
        nextButton.onClick.AddListener(SwapObject);

        UpdateInfoPanel();
    }

    void Update()
    {
        if (currentObject == null) return;

        if (Input.touchCount == 1 && (currentMode == InteractionMode.Rotate || currentMode == InteractionMode.Move))
        {
            Touch touch = Input.GetTouch(0);
            if (touch.phase == TouchPhase.Moved)
            {
                Vector2 delta = touch.deltaPosition;

                if (currentMode == InteractionMode.Rotate)
                {
                    float rotationSpeed = 0.2f;
                    currentObject.transform.Rotate(Vector3.up, -delta.x * rotationSpeed, Space.World);
                    currentObject.transform.Rotate(Vector3.right, delta.y * rotationSpeed, Space.World);
                }
                else if (currentMode == InteractionMode.Move)
                {
                    float moveSpeed = 0.01f;
                    currentObject.transform.Translate(new Vector3(delta.x * moveSpeed, delta.y * moveSpeed, 0), Space.World);
                }
            }
        }
        else if (Input.touchCount == 2 && currentMode == InteractionMode.Scale)
        {
            Touch touch1 = Input.GetTouch(0);
            Touch touch2 = Input.GetTouch(1);

            if (touch1.phase == TouchPhase.Moved || touch2.phase == TouchPhase.Moved)
            {
                float currentDistance = Vector2.Distance(touch1.position, touch2.position);
                if (initialDistance == 0)
                {
                    initialDistance = currentDistance;
                    initialScale = currentObject.transform.localScale;
                }

                float scaleFactor = currentDistance / initialDistance;
                currentObject.transform.localScale = initialScale * scaleFactor;
            }
        }

        if (Input.touchCount < 2)
        {
            initialDistance = 0; // Reset pinch distance
        }
    }

    void SetInteractionMode(InteractionMode mode)
    {
        currentMode = mode;
        UpdateInfoPanel();
    }

    void SwapObject()
    {
        if (objects.Length == 0) return;

        currentObject.SetActive(false);
        currentIndex = (currentIndex + 1) % objects.Length;
        currentObject = objects[currentIndex];
        SetObjectActive();

        UpdateInfoPanel();
    }

    void SetObjectActive()
    {
        currentObject.SetActive(true);
    }

    void UpdateInfoPanel()
    {
        string info = objectInfo["Markerless"] + "\n\n";

        switch (currentMode)
        {
            case InteractionMode.Rotate:
                info += objectInfo["Rotate"];
                break;
            case InteractionMode.Scale:
                info += objectInfo["Scale"];
                break;
            case InteractionMode.Move:
                info += objectInfo["Move"];
                break;
            default:
                info += "Select an interaction mode to get started.";
                break;
        }

        infoText.text = info;
        infoScrollView.verticalNormalizedPosition = 1; // Reset scroll position to top
    }
}
