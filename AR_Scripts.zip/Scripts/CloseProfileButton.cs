using UnityEngine;
using UnityEngine.UI;

public class CloseProfileButton : MonoBehaviour
{
    void Start()
    {
        GetComponent<Button>().onClick.AddListener(CloseProfilePanel);
    }

    void CloseProfilePanel()
    {
        var profileManager = FindObjectOfType<ProfileManager>();
        if (profileManager != null)
        {
            profileManager.profilePanel.SetActive(false);
        }
    }
}
