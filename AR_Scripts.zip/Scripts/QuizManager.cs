﻿using System.Collections.Generic;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using Firebase.Database;

[System.Serializable]
public class Question
{
    public string question;
    public string[] options;
    public int correctOption;
}

[System.Serializable]
public class QuestionList
{
    public List<Question> questions;
}

public class QuizManager : MonoBehaviour
{
    public Text questionText;
    public Toggle[] optionToggles;
    public Button nextButton;
    public Button prevButton;
    public Button submitButton;

    public GameObject resultPanel;
    public Text scoreText;
    public Text statusText;
    public Button retakeButton;

    private int currentQuestionIndex = 0;
    private List<Question> questions = new List<Question>();
    private Dictionary<int, int> userAnswers = new Dictionary<int, int>();
    private int passingScore = 5;
    private string chapterId;
    private int finalScore;
    public Button goToChapterButton; // 🔘 Assign this in Inspector


    // Firebase Database
    private DatabaseReference database;

    void Start()
    {
        if (string.IsNullOrEmpty(DatabaseManager.userId))
        {
            Debug.LogWarning("⚠️ No user logged in. Redirecting to login scene.");
            SceneManager.LoadScene("Login");
            return;
        }

        chapterId = ChapterManager.Instance.GetChapter();
        if (string.IsNullOrEmpty(chapterId))
        {
            Debug.LogError("❌ No chapter selected. Ensure ChapterManager is working correctly!");
            return;
        }

        database = FirebaseDatabase.DefaultInstance.RootReference;

        LoadQuestionsFromJson(chapterId);
        if (questions.Count > 0)
        {
            DisplayQuestion();
            StartCoroutine(ResetFirstToggleSelection());
        }
        else
        {
            Debug.LogError($"❌ No questions found for {chapterId}. Check the JSON file!");
        }

        nextButton.onClick.AddListener(NextQuestion);
        prevButton.onClick.AddListener(PreviousQuestion);
        submitButton.onClick.AddListener(SubmitQuiz);
        retakeButton.onClick.AddListener(RetakeQuiz);

        prevButton.gameObject.SetActive(false);
        submitButton.gameObject.SetActive(false);
        resultPanel.SetActive(false);
        goToChapterButton.gameObject.SetActive(false);
        goToChapterButton.onClick.AddListener(GoToChapter);

    }

    void LoadQuestionsFromJson(string chapter)
    {
        string resourcePath = $"QuizData/{chapter}";
        TextAsset jsonFile = Resources.Load<TextAsset>(resourcePath);

        if (jsonFile != null)
        {
            QuestionList questionData = JsonUtility.FromJson<QuestionList>(jsonFile.text);
            questions = questionData.questions;
            Debug.Log($"✅ Loaded {questions.Count} questions from Resources/{resourcePath}.json");
        }
        else
        {
            Debug.LogError($"❌ Quiz file not found: Resources/{resourcePath}.json.");
        }
    }

   void DisplayQuestion()
{
    if (currentQuestionIndex < 0 || currentQuestionIndex >= questions.Count) return;

    Question currentQuestion = questions[currentQuestionIndex];
    questionText.text = currentQuestion.question;

    // Get the ToggleGroup if assigned
    ToggleGroup toggleGroup = optionToggles[0].group;

    // Temporarily disable toggle group to reset all toggles
    if (toggleGroup != null) toggleGroup.allowSwitchOff = true;

    // Clear previous selections
    foreach (var toggle in optionToggles)
    {
        toggle.isOn = false;
    }

    for (int i = 0; i < optionToggles.Length; i++)
    {
        if (i < currentQuestion.options.Length)
        {
            optionToggles[i].gameObject.SetActive(true);
            optionToggles[i].GetComponentInChildren<Text>().text = currentQuestion.options[i];
        }
        else
        {
            optionToggles[i].gameObject.SetActive(false);
        }
    }

    // Restore previous answer if it exists
    if (userAnswers.ContainsKey(currentQuestionIndex))
    {
        int selectedIndex = userAnswers[currentQuestionIndex];
        if (selectedIndex >= 0 && selectedIndex < optionToggles.Length)
        {
            optionToggles[selectedIndex].isOn = true;
        }
    }

    // Re-enable toggle group logic
    if (toggleGroup != null) toggleGroup.allowSwitchOff = false;

    // Button visibility
    prevButton.gameObject.SetActive(currentQuestionIndex > 0);
    nextButton.gameObject.SetActive(currentQuestionIndex < questions.Count - 1);
    submitButton.gameObject.SetActive(currentQuestionIndex == questions.Count - 1);
}



    void NextQuestion()
    {
        SaveUserAnswer();
        currentQuestionIndex++;
        DisplayQuestion();
    }

    void PreviousQuestion()
    {
        SaveUserAnswer();
        currentQuestionIndex--;
        DisplayQuestion();
    }

    void SaveUserAnswer()
    {
        for (int i = 0; i < optionToggles.Length; i++)
        {
            if (optionToggles[i].isOn)
            {
                userAnswers[currentQuestionIndex] = i;
                break;
            }
        }
    }

    void SubmitQuiz()
    {
        SaveUserAnswer();
        finalScore = 0;

        for (int i = 0; i < questions.Count; i++)
        {
            if (userAnswers.ContainsKey(i) && userAnswers[i] == questions[i].correctOption)
            {
                finalScore++;
            }
        }

        ShowResult(finalScore);
        SaveQuizProgressToFirebase(finalScore);
    }

    void ShowResult(int score)
    {
        questionText.gameObject.SetActive(false);
        foreach (var toggle in optionToggles) toggle.gameObject.SetActive(false);
        nextButton.gameObject.SetActive(false);
        prevButton.gameObject.SetActive(false);
        submitButton.gameObject.SetActive(false);

        resultPanel.SetActive(true);
        scoreText.text = $"Score: {score} / {questions.Count}";
        goToChapterButton.gameObject.SetActive(true);


        if (score >= passingScore)
        {
            statusText.text = "✅ Passed!";
            statusText.color = Color.green;
            retakeButton.gameObject.SetActive(false);
        }
        else
        {
            statusText.text = "❌ Failed!";
            statusText.color = Color.red;
            retakeButton.gameObject.SetActive(true);
        }
    }

    void SaveQuizProgressToFirebase(int score)
    {
        if (string.IsNullOrEmpty(DatabaseManager.userId))
        {
            Debug.LogWarning("⚠️ Cannot save quiz progress. No user logged in.");
            return;
        }

        string userId = DatabaseManager.userId;
        string username = DatabaseManager.username;
        string email = DatabaseManager.userEmail; // ✅ Get email from DatabaseManager

        DatabaseReference chapterRef = database.Child($"chapters/{chapterId}");
        DatabaseReference userProgressRef = database.Child($"users/{userId}/progress/{chapterId}");

        // Update quiz completion for user under chapters
        chapterRef.Child("quizUsers").Child(userId).SetValueAsync(true);

        // Increment totalQuizzes count
        chapterRef.Child("totalQuizzes").RunTransaction(mutableData =>
        {
            int totalQuizzes = (mutableData.Value == null) ? 0 : int.Parse(mutableData.Value.ToString());
            mutableData.Value = totalQuizzes + 1;
            return TransactionResult.Success(mutableData);
        });

        // Store user's quiz progress with email
        ChapterProgress progress = new ChapterProgress(true, score, username, email);
        string json = JsonUtility.ToJson(progress);

        userProgressRef.SetRawJsonValueAsync(json).ContinueWith(task =>
        {
            if (task.IsCompleted)
            {
                Debug.Log($"✅ Quiz progress saved: {json}");
            }
            else
            {
                Debug.LogError("❌ Failed to save quiz progress.");
            }
        });
    }

    void RetakeQuiz()
    {
        userAnswers.Clear();
        currentQuestionIndex = 0;

        questionText.gameObject.SetActive(true);
        foreach (var toggle in optionToggles) toggle.gameObject.SetActive(true);
        nextButton.gameObject.SetActive(true);
        prevButton.gameObject.SetActive(true);
        submitButton.gameObject.SetActive(true);
        resultPanel.SetActive(false);

        DisplayQuestion();
    }
    void GoToChapter()
    {
        string chapterSceneName = ChapterManager.Instance.GetChapter();  // e.g., "MarkerbasedTut", "MarkerlessTut"
        Debug.Log("📘 Loading chapter scene: " + chapterSceneName);
        SceneManager.LoadScene(chapterSceneName);
    }

    IEnumerator ResetFirstToggleSelection()
{
    // Wait one frame to let Unity fully initialize UI
    yield return null;

    // Ensure all toggles are off for the first question unless a user answer exists
    if (!userAnswers.ContainsKey(currentQuestionIndex))
    {
        ToggleGroup group = optionToggles[0].group;
        if (group != null) group.allowSwitchOff = true;

        foreach (var toggle in optionToggles)
        {
            toggle.isOn = false;
        }

        if (group != null) group.allowSwitchOff = false;
    }
}

}


