using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class SlideBarManager : MonoBehaviour
{
    public RectTransform slideBarPanel;
    public Button profileButton, closeButton, logOutButton, viewProfileButton;
    public GameObject profilePanel;

    private bool isSlideBarOpen = false;
    private ProfileManager profileManager;

    void Start()
    {
        slideBarPanel.anchoredPosition = new Vector2(300, slideBarPanel.anchoredPosition.y);

        profileButton.onClick.AddListener(ToggleSlideBar);
        closeButton.onClick.AddListener(ToggleSlideBar);
        logOutButton.onClick.AddListener(LogOutUser);
        viewProfileButton.onClick.AddListener(OpenProfilePanel);

        // Reference ProfileManager
        profileManager = FindObjectOfType<ProfileManager>();
    }

    void ToggleSlideBar()
    {
        float targetX = isSlideBarOpen ? 300 : 0;
        slideBarPanel.DOAnchorPosX(targetX, 0.3f);
        isSlideBarOpen = !isSlideBarOpen;
    }

    void OpenProfilePanel()
    {
        if (profilePanel != null && profileManager != null)
        {
            profilePanel.SetActive(true);
            profileManager.OpenProfile(); // ✅ Load profile data
            ToggleSlideBar(); // Close the sidebar
        }
    }

    void LogOutUser()
    {
        PlayerPrefs.DeleteKey("userId");
        PlayerPrefs.DeleteKey("username");
        PlayerPrefs.DeleteKey("email");
        PlayerPrefs.Save();
        UnityEngine.SceneManagement.SceneManager.LoadScene("Login");
    }
}
